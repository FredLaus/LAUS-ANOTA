# LAUS — Soluções em Tecnologia

Gerenciador de pedidos para restaurantes (tema escuro premium). 100% gratuito, sem assinatura, sem gateway de pagamento, dados locais em SQLite.

## Como rodar

```bash
npm install
npx expo install --fix      # alinha as versões das bibliotecas ao Expo SDK 53
npx expo run:android        # build de desenvolvimento (recomendado)
```

> Use **build de desenvolvimento** (`expo run:android` / `expo-dev-client`), não o Expo Go:
> as notificações locais e o alarme dependem de módulos nativos que o Expo Go não suporta por completo.

## Logo

Coloque a logo em `assets/logo.png` e, em `src/config.js`, troque

```js
export const LOGO_IMAGE = null;
```
por
```js
export const LOGO_IMAGE = require('../assets/logo.png');
```

Também troque `SUPPORT.whatsapp` e `SUPPORT.email` em `src/config.js` pelos contatos reais.

## O que tem

| Recurso | Onde |
|---|---|
| Splash 2,5 s com barra de carregamento | `src/screens/SplashScreen.js` |
| Abas inferiores + menu lateral (hambúrguer) | `src/navigation/index.js` |
| Esteira de pedidos (3 abas deslizantes), cronômetro verde/amarelo/vermelho piscando | `OrdersScreen.js`, `OrderCard.js` |
| Notificação local ao zerar o cronômetro | `src/services/notifications.js` |
| Campainha em loop até aceitar o pedido | `src/services/alertSound.js` + `assets/alert.wav` |
| Faturamento da Noite: fechamento 06:30, gráfico mensal, comparativo | `RevenueScreen.js`, `src/services/closing.js` |
| Cardápio: categorias, +, editar, edição direta de nome/preço, chave liga/desliga | `MenuScreen.js` |
| Histórico com busca em tempo real | `HistoryScreen.js` |
| LED do WhatsApp + modal com QR e "Reconectar WhatsApp" | `TopBar.js`, `WhatsAppModal.js`, `src/services/whatsapp.js` |
| Tempo de alerta configurável | `SettingsScreen.js` |

## Notas importantes

- **Fechamento das 06:30:** é um "cron simulado". Roda ao abrir o app, ao voltar ao primeiro plano e a cada minuto; se o app estava fechado às 06:30, o fechamento é recuperado na próxima abertura. Um worker nativo em segundo plano com o app totalmente fechado não está incluído.
- **Notificação de atraso:** é agendada no momento em que o pedido entra, então dispara mesmo com o app em segundo plano.
- **Robô do WhatsApp:** o app espera um serviço local com os endpoints descritos em `src/services/whatsapp.js`. Informe o endereço em Configurações Gerais. Sem robô, o LED fica vermelho e você pode usar o botão "＋ Teste" na tela de Pedidos para simular pedidos.
- **Dados de demonstração:** na primeira abertura são criados itens de cardápio e um histórico de faturamento fictício para o gráfico aparecer. Apague em Configurações Gerais > Limpar dados de demonstração.
- **Chave de disponibilidade:** grava "indisponível" no banco e esmaece o item. O app ainda não tem tela de nova venda; o pedido de teste já ignora itens indisponíveis, e o robô pode consultar essa informação quando você integrá-lo.
