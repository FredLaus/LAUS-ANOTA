// Banco de dados local (SQLite) — o app funciona 100% offline e sem mensalidade.
import * as SQLite from 'expo-sqlite';
import { DEFAULT_SETTINGS } from './config';
import { dateKey, latestDue } from './utils';

let _dbPromise = null;

export function db() {
  if (!_dbPromise) {
    _dbPromise = (async () => {
      const d = await SQLite.openDatabaseAsync('laus.db');
      await d.execAsync(`
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          external_id TEXT,
          number TEXT,
          customer TEXT NOT NULL,
          items TEXT NOT NULL,
          notes TEXT,
          payment TEXT,
          total REAL NOT NULL,
          status TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          timer_start INTEGER NOT NULL,
          timer_limit_min INTEGER NOT NULL,
          finished_at INTEGER,
          notif_id TEXT
        );
        CREATE TABLE IF NOT EXISTS menu_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          description TEXT,
          price REAL NOT NULL,
          category TEXT NOT NULL,
          photo TEXT,
          available INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS daily_revenue (
          date TEXT PRIMARY KEY,
          total REAL NOT NULL,
          orders_count INTEGER NOT NULL
        );
      `);
      return d;
    })();
  }
  return _dbPromise;
}

/* ---------- Configurações ---------- */
export async function getSettings() {
  const d = await db();
  const rows = await d.getAllAsync('SELECT key, value FROM settings');
  const out = { ...DEFAULT_SETTINGS };
  rows.forEach((r) => (out[r.key] = r.value));
  return out;
}

export async function setSetting(key, value) {
  const d = await db();
  await d.runAsync('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, String(value)]);
}

/* ---------- Pedidos ---------- */
const parseOrder = (r) => (r ? { ...r, items: JSON.parse(r.items || '[]') } : null);

export async function getActiveOrders() {
  const d = await db();
  const rows = await d.getAllAsync(
    "SELECT * FROM orders WHERE status IN ('analise','producao','entrega') ORDER BY created_at ASC"
  );
  return rows.map(parseOrder);
}

export async function getOrder(id) {
  const d = await db();
  return parseOrder(await d.getFirstAsync('SELECT * FROM orders WHERE id = ?', [id]));
}

// Retorna o id criado, ou null se o pedido externo já existia
export async function insertOrder(o) {
  const d = await db();
  if (o.external_id) {
    const dup = await d.getFirstAsync('SELECT id FROM orders WHERE external_id = ?', [o.external_id]);
    if (dup) return null;
  }
  const now = Date.now();
  const r = await d.runAsync(
    `INSERT INTO orders (external_id, number, customer, items, notes, payment, total, status, created_at, timer_start, timer_limit_min)
     VALUES (?, '', ?, ?, ?, ?, ?, 'analise', ?, ?, ?)`,
    [o.external_id || null, o.customer, JSON.stringify(o.items), o.notes || '', o.payment || 'Pix', o.total, now, now, o.timer_limit_min]
  );
  const id = r.lastInsertRowId;
  await d.runAsync('UPDATE orders SET number = ? WHERE id = ?', [String(1000 + id), id]);
  return id;
}

export async function updateOrder(id, patch) {
  const d = await db();
  const keys = Object.keys(patch);
  if (!keys.length) return;
  await d.runAsync(
    `UPDATE orders SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`,
    [...keys.map((k) => patch[k]), id]
  );
}

// Busca em tempo real por nome do cliente ou número do pedido
export async function searchHistory(query, statusFilter) {
  const d = await db();
  const q = `%${String(query || '').replace(/^#/, '').trim()}%`;
  const statuses = statusFilter ? [statusFilter] : ['finalizado', 'cancelado'];
  const rows = await d.getAllAsync(
    `SELECT * FROM orders
     WHERE status IN (${statuses.map(() => '?').join(',')})
       AND (customer LIKE ? OR number LIKE ?)
     ORDER BY created_at DESC LIMIT 200`,
    [...statuses, q, q]
  );
  return rows.map(parseOrder);
}

/* ---------- Cardápio ---------- */
export async function getMenu() {
  const d = await db();
  return d.getAllAsync('SELECT * FROM menu_items ORDER BY category, name');
}

export async function saveMenuItem(item) {
  const d = await db();
  if (item.id) {
    await d.runAsync(
      'UPDATE menu_items SET name=?, description=?, price=?, category=?, photo=? WHERE id=?',
      [item.name, item.description || '', item.price, item.category, item.photo || null, item.id]
    );
  } else {
    await d.runAsync(
      'INSERT INTO menu_items (name, description, price, category, photo, available) VALUES (?,?,?,?,?,1)',
      [item.name, item.description || '', item.price, item.category, item.photo || null]
    );
  }
}

export async function patchMenuItem(id, patch) {
  const d = await db();
  const keys = Object.keys(patch);
  await d.runAsync(
    `UPDATE menu_items SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`,
    [...keys.map((k) => patch[k]), id]
  );
}

export async function deleteMenuItem(id) {
  const d = await db();
  await d.runAsync('DELETE FROM menu_items WHERE id = ?', [id]);
}

/* ---------- Faturamento ---------- */
export async function getRevenue() {
  const d = await db();
  return d.getAllAsync('SELECT * FROM daily_revenue ORDER BY date ASC');
}

export async function upsertRevenue(date, total, count) {
  const d = await db();
  await d.runAsync(
    'INSERT OR REPLACE INTO daily_revenue (date, total, orders_count) VALUES (?, ?, ?)',
    [date, total, count]
  );
}

export async function sumFinishedBetween(startMs, endMs) {
  const d = await db();
  const r = await d.getFirstAsync(
    `SELECT COALESCE(SUM(total), 0) AS total, COUNT(*) AS n FROM orders
     WHERE status = 'finalizado' AND finished_at >= ? AND finished_at < ?`,
    [startMs, endMs]
  );
  return { total: r.total, count: r.n };
}

/* ---------- Dados de demonstração ---------- */
const SEED_MENU = [
  ['X-Burger Clássico', 'Pão brioche, blend 160g, queijo e molho da casa', 28.9, 'Hambúrgueres'],
  ['X-Bacon Duplo', 'Dois blends, muito bacon crocante e cheddar', 38.9, 'Hambúrgueres'],
  ['Coca-Cola Lata', '350ml gelada', 6.5, 'Bebidas'],
  ['Suco de Laranja', 'Natural 400ml', 9.0, 'Bebidas'],
  ['Brownie com Sorvete', 'Brownie quente com bola de creme', 18.0, 'Sobremesas'],
  ['Combo Casal', '2 X-Burger + batata grande + 2 refrigerantes', 79.9, 'Combos'],
];

export async function seedDemoIfNeeded() {
  const s = await getSettings();
  if (s.seeded === '1') return;
  const d = await db();
  for (const [name, description, price, category] of SEED_MENU) {
    await d.runAsync(
      'INSERT INTO menu_items (name, description, price, category, photo, available) VALUES (?,?,?,?,NULL,1)',
      [name, description, price, category]
    );
  }
  // Histórico de faturamento de demonstração (mês passado + mês atual até anteontem do último fechamento)
  const due = latestDue(new Date());
  const lastRevenueDay = new Date(due);
  lastRevenueDay.setDate(lastRevenueDay.getDate() - 2);
  const start = new Date(lastRevenueDay.getFullYear(), lastRevenueDay.getMonth() - 1, 1);
  const rnd = (i) => {
    const x = Math.sin(i * 12.9898) * 43758.5453;
    return x - Math.floor(x);
  };
  let i = 0;
  for (let day = new Date(start); day <= lastRevenueDay; day.setDate(day.getDate() + 1), i++) {
    const weekend = [5, 6].includes(day.getDay()) ? 1.6 : 1;
    const growth = day.getMonth() === lastRevenueDay.getMonth() ? 1.12 : 1;
    const total = Math.round((700 + rnd(i) * 900) * weekend * growth * 100) / 100;
    await d.runAsync('INSERT OR REPLACE INTO daily_revenue (date, total, orders_count) VALUES (?,?,?)', [
      dateKey(day),
      total,
      Math.round(total / 38),
    ]);
  }
  // O fechamento já considera tudo até o dia anterior ao próximo a rodar
  const prevRun = new Date(due);
  prevRun.setDate(prevRun.getDate() - 1);
  await setSetting('last_closing', dateKey(prevRun));
  await setSetting('seeded', '1');
}

export async function clearDemoData() {
  const d = await db();
  await d.execAsync('DELETE FROM orders; DELETE FROM menu_items; DELETE FROM daily_revenue;');
}
