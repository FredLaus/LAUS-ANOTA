// Estado global do app: pedidos, cardápio, configurações, faturamento e status do robô.
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';
import * as D from '../db';
import { setupNotifications, scheduleLate, cancelScheduled } from '../services/notifications';
import { startAlarm, stopAlarm } from '../services/alertSound';
import { runPendingClosings, forceClosing } from '../services/closing';
import * as WA from '../services/whatsapp';
import { printOrder } from '../services/print';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

const NAMES = ['Ana Souza', 'Carlos Lima', 'Marina Alves', 'João Pedro', 'Fernanda Costa', 'Rafael Dias'];
const NOTES = ['Sem cebola', 'Ponto da carne bem passado', 'Capricha no molho', '', 'Sem picles', ''];
const PAYMENTS = ['Pix', 'Cartão', 'Dinheiro'];

export function AppProvider({ children }) {
  const [ready, setReady] = useState(false);
  const [orders, setOrders] = useState([]);
  const [menu, setMenu] = useState([]);
  const [settings, setSettings] = useState({});
  const [revenue, setRevenue] = useState([]);
  const [bot, setBot] = useState({ online: false, qr: null });
  const [waModalOpen, setWaModalOpen] = useState(false);
  const settingsRef = useRef({});
  settingsRef.current = settings;

  const reload = useCallback(async () => {
    const [o, m, s, r] = await Promise.all([D.getActiveOrders(), D.getMenu(), D.getSettings(), D.getRevenue()]);
    setOrders(o);
    setMenu(m);
    setSettings(s);
    setRevenue(r);
  }, []);

  /* ---------- Inicialização ---------- */
  useEffect(() => {
    (async () => {
      await D.db();
      await D.seedDemoIfNeeded();
      await setupNotifications();
      await runPendingClosings();
      await reload();
      setReady(true);
    })();
  }, [reload]);

  /* ---------- "Cron" das 06:30: checa a cada minuto e ao voltar ao app ---------- */
  useEffect(() => {
    if (!ready) return undefined;
    const check = async () => {
      const ran = await runPendingClosings();
      if (ran > 0) setRevenue(await D.getRevenue());
    };
    const t = setInterval(check, 60000);
    const sub = AppState.addEventListener('change', (st) => st === 'active' && check());
    return () => {
      clearInterval(t);
      sub.remove();
    };
  }, [ready]);

  /* ---------- Pedidos ---------- */
  const addOrder = useCallback(
    async (o) => {
      const s = await D.getSettings();
      const limit = parseInt(s.timer_limit_min, 10) || 20; // herda o tempo configurado
      const id = await D.insertOrder({ ...o, timer_limit_min: limit });
      if (id) {
        const ord = await D.getOrder(id);
        const nid = await scheduleLate(ord, ord.timer_start + limit * 60000);
        if (nid) await D.updateOrder(id, { notif_id: nid });
      }
      await reload();
      return id;
    },
    [reload]
  );

  const moveOrder = useCallback(
    async (order, status) => {
      const patch = { status };
      if (status === 'finalizado' || status === 'cancelado') patch.finished_at = Date.now();
      if (['entrega', 'finalizado', 'cancelado'].includes(status) && order.notif_id) {
        await cancelScheduled(order.notif_id); // cronômetro encerrado
        patch.notif_id = null;
      }
      await D.updateOrder(order.id, patch);
      await reload();
      // Impressão automática ao aceitar o pedido (se ativada em Configurações de Impressão)
      if (status === 'producao' && settingsRef.current.print_auto === '1') {
        printOrder(order, settingsRef.current).catch(() => {});
      }
    },
    [reload]
  );

  // Pedido de teste (útil sem o robô conectado)
  const addDemoOrder = useCallback(async () => {
    const available = menu.filter((m) => m.available === 1);
    if (!available.length) return null;
    const n = 1 + Math.floor(Math.random() * 3);
    const items = [];
    let total = 0;
    for (let i = 0; i < n; i++) {
      const it = available[Math.floor(Math.random() * available.length)];
      const qty = 1 + Math.floor(Math.random() * 2);
      items.push({ name: it.name, qty });
      total += it.price * qty;
    }
    return addOrder({
      customer: NAMES[Math.floor(Math.random() * NAMES.length)],
      items,
      notes: NOTES[Math.floor(Math.random() * NOTES.length)],
      payment: PAYMENTS[Math.floor(Math.random() * PAYMENTS.length)],
      total: Math.round(total * 100) / 100,
    });
  }, [menu, addOrder]);

  /* ---------- Alarme contínuo enquanto houver pedido em "Em Análise" ---------- */
  const hasPending = orders.some((o) => o.status === 'analise');
  const alarmOn = settings.alarm_enabled !== '0';
  useEffect(() => {
    if (!ready) return;
    if (hasPending && alarmOn) startAlarm();
    else stopAlarm();
  }, [hasPending, alarmOn, ready]);

  /* ---------- Cardápio ---------- */
  const saveItem = useCallback(async (item) => { await D.saveMenuItem(item); await reload(); }, [reload]);
  const patchItem = useCallback(async (id, patch) => { await D.patchMenuItem(id, patch); await reload(); }, [reload]);
  const removeItem = useCallback(async (id) => { await D.deleteMenuItem(id); await reload(); }, [reload]);

  /* ---------- Configurações ---------- */
  const setSetting = useCallback(async (k, v) => {
    await D.setSetting(k, v);
    setSettings((s) => ({ ...s, [k]: String(v) }));
  }, []);

  /* ---------- Faturamento ---------- */
  const closeNow = useCallback(async () => {
    const r = await forceClosing();
    setRevenue(await D.getRevenue());
    return r;
  }, []);

  const clearDemo = useCallback(async () => {
    await D.clearDemoData();
    await reload();
  }, [reload]);

  /* ---------- Robô do WhatsApp: status (LED) + novos pedidos ---------- */
  const refreshBot = useCallback(async () => {
    const url = settingsRef.current.bot_url;
    const online = await WA.fetchStatus(url);
    const qr = online ? null : await WA.fetchQr(url);
    setBot({ online, qr });
    if (online) {
      const pending = await WA.fetchPendingOrders(url);
      const ids = [];
      for (const p of pending) {
        await addOrder({
          external_id: String(p.externalId),
          customer: p.customer,
          items: p.items || [],
          notes: p.notes,
          payment: p.payment,
          total: Number(p.total) || 0,
        });
        ids.push(p.externalId);
      }
      if (ids.length) await WA.ackOrders(url, ids);
    }
  }, [addOrder]);

  const reconnectBot = useCallback(async () => {
    await WA.reconnect(settingsRef.current.bot_url);
    await refreshBot();
  }, [refreshBot]);

  useEffect(() => {
    if (!ready) return undefined;
    refreshBot();
    const t = setInterval(refreshBot, 10000);
    return () => clearInterval(t);
  }, [ready, refreshBot, settings.bot_url]);

  const value = {
    ready, orders, menu, settings, revenue, bot,
    waModalOpen, setWaModalOpen,
    addOrder, moveOrder, addDemoOrder,
    saveItem, patchItem, removeItem,
    setSetting, closeNow, clearDemo,
    refreshBot, reconnectBot,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
