// Configurações fixas do app LAUS (100% gratuito, sem cobranças).
export const APP_NAME = 'LAUS';
export const TAGLINE = 'Soluções em Tecnologia';

// Para usar a imagem real da logo: coloque o arquivo em assets/logo.png
// e troque a linha abaixo por:  export const LOGO_IMAGE = require('../assets/logo.png');
export const LOGO_IMAGE = null;

// Contatos do Suporte Integrado (TROQUE pelos seus dados reais)
export const SUPPORT = {
  whatsapp: '5527999999999', // DDI + DDD + número, só dígitos
  email: 'suporte@laus.example',
};

// Fechamento diário do faturamento
export const CLOSING_HOUR = 6;
export const CLOSING_MIN = 30;

// Valores padrão das configurações (gravados no SQLite)
export const DEFAULT_SETTINGS = {
  timer_limit_min: '20',
  alarm_enabled: '1',
  bot_url: '',
  rest_name: 'Meu Restaurante',
  rest_phone: '',
  rest_address: '',
  print_auto: '0',
  print_width: '80',
  print_copies: '1',
  print_header: 'LAUS - Soluções em Tecnologia',
};
