// Navegação: Drawer (menu hambúrguer) contendo as abas inferiores.
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItem } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';
import Logo from '../components/Logo';
import { colors } from '../theme';
import { APP_NAME, TAGLINE } from '../config';
import OrdersScreen from '../screens/OrdersScreen';
import MenuScreen from '../screens/MenuScreen';
import RevenueScreen from '../screens/RevenueScreen';
import ProfileScreen from '../screens/ProfileScreen';
import HistoryScreen from '../screens/HistoryScreen';
import PrintScreen from '../screens/PrintScreen';
import SupportScreen from '../screens/SupportScreen';
import SettingsScreen from '../screens/SettingsScreen';

const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

export const navRef = React.createRef();

const theme = {
  ...DarkTheme,
  colors: { ...DarkTheme.colors, background: colors.bg, card: colors.bg, text: colors.text, border: colors.border, primary: colors.neon },
};

const TAB_ICONS = {
  Pedidos: 'receipt-outline',
  Cardapio: 'restaurant-outline',
  Relatorios: 'bar-chart-outline',
  Voce: 'person-circle-outline',
};

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.bg, borderTopColor: colors.border, height: 64, paddingBottom: 8, paddingTop: 6 },
        tabBarActiveTintColor: colors.neon,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontWeight: '700', fontSize: 11 },
        tabBarIcon: ({ color, size }) => <Ionicons name={TAB_ICONS[route.name]} size={size} color={color} />,
      })}
    >
      <Tab.Screen name="Pedidos" component={OrdersScreen} />
      <Tab.Screen name="Cardapio" component={MenuScreen} options={{ title: 'Cardápio', tabBarLabel: 'Cardápio' }} />
      <Tab.Screen name="Relatorios" component={RevenueScreen} options={{ title: 'Relatórios', tabBarLabel: 'Relatórios' }} />
      <Tab.Screen name="Voce" component={ProfileScreen} options={{ title: 'Você', tabBarLabel: 'Você' }} />
    </Tab.Navigator>
  );
}

// Links rápidos do menu lateral: [rótulo, ícone, destino]
const LINKS = [
  ['Perfil do Restaurante', 'storefront-outline', ['Inicio', { screen: 'Voce' }]],
  ['Configurações de Impressão', 'print-outline', ['Impressao']],
  ['Suporte Integrado', 'headset-outline', ['Suporte']],
  ['Histórico de Pedidos', 'time-outline', ['Historico']],
  ['Configurações Gerais', 'settings-outline', ['Configuracoes']],
];

function DrawerContent(props) {
  return (
    <DrawerContentScrollView {...props} contentContainerStyle={{ paddingTop: 0 }}>
      <View style={styles.head}>
        <Logo size={64} />
        <Text style={styles.brand}>{APP_NAME}</Text>
        <Text style={styles.tag}>{TAGLINE}</Text>
      </View>
      {LINKS.map(([label, icon, target]) => (
        <DrawerItem
          key={label}
          label={label}
          labelStyle={{ color: colors.text, fontWeight: '600' }}
          icon={() => <Ionicons name={icon} size={22} color={colors.neon} />}
          onPress={() => {
            props.navigation.navigate(...target);
            props.navigation.closeDrawer();
          }}
        />
      ))}
    </DrawerContentScrollView>
  );
}

export default function Navigation() {
  return (
    <NavigationContainer ref={navRef} theme={theme}>
      <Drawer.Navigator
        drawerContent={(p) => <DrawerContent {...p} />}
        screenOptions={{
          headerShown: false,
          drawerPosition: 'right',
          drawerStyle: { backgroundColor: colors.card, width: 290 },
          overlayColor: 'rgba(0,0,0,0.7)',
        }}
      >
        <Drawer.Screen name="Inicio" component={Tabs} />
        <Drawer.Screen name="Historico" component={HistoryScreen} />
        <Drawer.Screen name="Impressao" component={PrintScreen} />
        <Drawer.Screen name="Suporte" component={SupportScreen} />
        <Drawer.Screen name="Configuracoes" component={SettingsScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  head: { alignItems: 'center', paddingTop: 60, paddingBottom: 24, marginBottom: 8, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.bg },
  brand: { color: colors.text, fontSize: 24, fontWeight: '900', letterSpacing: 4, marginTop: 10 },
  tag: { color: colors.neon, fontSize: 12, marginTop: 2 },
});
