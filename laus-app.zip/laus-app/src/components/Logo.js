// Logo LAUS. Usa a imagem real se LOGO_IMAGE estiver definido em config.js;
// caso contrário desenha um escudo provisório em SVG.
import React from 'react';
import { Image } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { LOGO_IMAGE } from '../config';
import { colors } from '../theme';

export default function Logo({ size = 40 }) {
  if (LOGO_IMAGE) {
    return <Image source={LOGO_IMAGE} style={{ width: size, height: size }} resizeMode="contain" />;
  }
  return (
    <Svg width={size} height={size} viewBox="0 0 100 100">
      <Path
        d="M50 5 L88 18 V48 C88 72 72 88 50 96 C28 88 12 72 12 48 V18 Z"
        fill={colors.card}
        stroke={colors.neon}
        strokeWidth={5}
        strokeLinejoin="round"
      />
      <Path d="M39 30 V67 H64" stroke={colors.neon} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </Svg>
  );
}
