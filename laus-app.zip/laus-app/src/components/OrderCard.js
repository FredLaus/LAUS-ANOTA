// Card de pedido com cronômetro regressivo colorido.
import React, { useEffect, useRef } from 'react';
import { Alert, Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius } from '../theme';
import { fmtClock, fmtMoney, timerInfo } from '../utils';

function Countdown({ order, now }) {
  const { remaining, color, late } = timerInfo(order, now, colors);
  const blink = useRef(new Animated.Value(1)).current;

  // Pisca em vermelho quando zera
  useEffect(() => {
    if (!late) {
      blink.setValue(1);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(blink, { toValue: 0.2, duration: 450, useNativeDriver: true }),
        Animated.timing(blink, { toValue: 1, duration: 450, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [late, blink]);

  return (
    <Animated.View style={[styles.timer, { borderColor: color, opacity: blink }]}>
      <Text style={[styles.timerText, { color }]}>
        {late ? `ATRASADO +${fmtClock(remaining)}` : `⏱ ${fmtClock(remaining)}`}
      </Text>
    </Animated.View>
  );
}

const ACTIONS = {
  analise: { label: 'Aceitar Pedido', next: 'producao' },
  producao: { label: 'Pronto — Saiu / Retirada', next: 'entrega' },
  entrega: { label: 'Finalizar Pedido', next: 'finalizado' },
};

export default function OrderCard({ order, now, onMove }) {
  const action = ACTIONS[order.status];
  const showTimer = order.status === 'analise' || order.status === 'producao';

  const refuse = () =>
    Alert.alert('Recusar pedido', `Cancelar o pedido #${order.number} de ${order.customer}?`, [
      { text: 'Voltar', style: 'cancel' },
      { text: 'Recusar', style: 'destructive', onPress: () => onMove(order, 'cancelado') },
    ]);

  return (
    <View style={styles.card}>
      <View style={styles.head}>
        <View style={{ flex: 1 }}>
          <Text style={styles.number}>#{order.number}</Text>
          <Text style={styles.customer}>{order.customer}</Text>
        </View>
        {showTimer && <Countdown order={order} now={now} />}
      </View>

      <View style={styles.items}>
        {order.items.map((it, i) => (
          <Text key={i} style={styles.item}>• {it.qty}x {it.name}</Text>
        ))}
      </View>

      {!!order.notes && <Text style={styles.notes}>📝 Obs: {order.notes}</Text>}

      <View style={styles.foot}>
        <Text style={styles.pay}>💳 {order.payment}</Text>
        <Text style={styles.total}>{fmtMoney(order.total)}</Text>
      </View>

      <View style={styles.actions}>
        {order.status === 'analise' && (
          <Pressable style={styles.refuse} onPress={refuse}>
            <Text style={styles.refuseText}>Recusar</Text>
          </Pressable>
        )}
        <Pressable style={styles.accept} onPress={() => onMove(order, action.next)}>
          <Text style={styles.acceptText}>{action.label}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.card, borderRadius: radius.md, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  head: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  number: { color: colors.neon, fontWeight: '800', fontSize: 14 },
  customer: { color: colors.text, fontWeight: '700', fontSize: 18 },
  timer: { borderWidth: 2, borderRadius: radius.sm, paddingHorizontal: 10, paddingVertical: 6 },
  timerText: { fontWeight: '800', fontSize: 15, fontVariant: ['tabular-nums'] },
  items: { marginBottom: 6, gap: 2 },
  item: { color: colors.text, fontSize: 15 },
  notes: { color: colors.yellow, marginTop: 4, marginBottom: 4 },
  foot: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border },
  pay: { color: colors.muted, fontWeight: '600' },
  total: { color: colors.green, fontWeight: '800', fontSize: 20 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  refuse: { paddingVertical: 12, paddingHorizontal: 16, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.red },
  refuseText: { color: colors.red, fontWeight: '700' },
  accept: { flex: 1, backgroundColor: colors.neon, borderRadius: radius.sm, paddingVertical: 12, alignItems: 'center' },
  acceptText: { color: '#000', fontWeight: '800', fontSize: 15 },
});
