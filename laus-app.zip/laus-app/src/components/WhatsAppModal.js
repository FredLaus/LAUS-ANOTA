// Painel flutuante do status do WhatsApp: botão "Reconectar" + área do QR de pareamento.
import React, { useState } from 'react';
import { ActivityIndicator, Alert, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import { colors, radius } from '../theme';
import { useApp } from '../context/AppContext';

export default function WhatsAppModal({ onOpenSettings }) {
  const { waModalOpen, setWaModalOpen, bot, settings, reconnectBot, refreshBot } = useApp();
  const [busy, setBusy] = useState(false);
  const hasUrl = !!(settings.bot_url || '').trim();

  const doReconnect = async () => {
    setBusy(true);
    try {
      await reconnectBot();
    } catch (e) {
      Alert.alert('Não foi possível reconectar', 'Verifique se o robô está ligado e se o endereço está correto em Configurações Gerais.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal visible={waModalOpen} transparent animationType="fade" onRequestClose={() => setWaModalOpen(false)}>
      <View style={styles.backdrop}>
        <View style={styles.panel}>
          <View style={styles.row}>
            <View style={[styles.dot, { backgroundColor: bot.online ? colors.green : colors.red }]} />
            <Text style={styles.title}>{bot.online ? 'WhatsApp conectado' : 'WhatsApp desconectado'}</Text>
          </View>

          <View style={styles.qrBox}>
            {bot.online ? (
              <Text style={styles.hint}>O robô está ativo e recebendo pedidos.</Text>
            ) : bot.qr ? (
              <QRCode value={bot.qr} size={200} backgroundColor="#fff" color="#000" />
            ) : (
              <Text style={styles.hint}>
                {hasUrl
                  ? 'Aguardando o código QR de pareamento do robô…'
                  : 'Espaço reservado para o QR de pareamento. Informe o endereço do robô em Configurações Gerais.'}
              </Text>
            )}
          </View>

          <Pressable style={[styles.btn, busy && { opacity: 0.6 }]} onPress={doReconnect} disabled={busy || !hasUrl}>
            {busy ? <ActivityIndicator color="#000" /> : <Text style={styles.btnText}>Reconectar WhatsApp</Text>}
          </Pressable>
          <Pressable style={styles.btnGhost} onPress={refreshBot}>
            <Text style={styles.ghostText}>Atualizar status</Text>
          </Pressable>
          {!hasUrl && (
            <Pressable
              style={styles.btnGhost}
              onPress={() => {
                setWaModalOpen(false);
                onOpenSettings && onOpenSettings();
              }}
            >
              <Text style={styles.ghostText}>Abrir Configurações Gerais</Text>
            </Pressable>
          )}
          <Pressable style={styles.btnGhost} onPress={() => setWaModalOpen(false)}>
            <Text style={[styles.ghostText, { color: colors.muted }]}>Fechar</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'center', padding: 24 },
  panel: { backgroundColor: colors.card, borderRadius: radius.lg, padding: 20, borderWidth: 1, borderColor: colors.border },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 16 },
  dot: { width: 14, height: 14, borderRadius: 7 },
  title: { color: colors.text, fontSize: 18, fontWeight: '700' },
  qrBox: {
    minHeight: 220, alignItems: 'center', justifyContent: 'center', padding: 12,
    borderRadius: radius.md, borderWidth: 1, borderStyle: 'dashed', borderColor: colors.neon, marginBottom: 16,
  },
  hint: { color: colors.muted, textAlign: 'center', lineHeight: 20 },
  btn: { backgroundColor: colors.neon, borderRadius: radius.md, paddingVertical: 14, alignItems: 'center' },
  btnText: { color: '#000', fontWeight: '800', fontSize: 16 },
  btnGhost: { paddingVertical: 12, alignItems: 'center' },
  ghostText: { color: colors.neon, fontWeight: '600' },
});
