// Navbar superior: logo à esquerda, título, LED do WhatsApp e menu hambúrguer à direita.
import React, { useEffect, useRef } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Logo from './Logo';
import { colors } from '../theme';
import { useApp } from '../context/AppContext';

export default function TopBar({ title, right }) {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const { bot, setWaModalOpen } = useApp();
  const glow = useRef(new Animated.Value(0.5)).current;

  // LED "respirando"
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, { toValue: 1, duration: 900, useNativeDriver: true }),
        Animated.timing(glow, { toValue: 0.5, duration: 900, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [glow]);

  const ledColor = bot.online ? colors.green : colors.red;

  return (
    <View style={[styles.bar, { paddingTop: insets.top + 8 }]}>
      <Logo size={34} />
      <Text style={styles.title} numberOfLines={1}>{title}</Text>
      {right}
      <Pressable onPress={() => setWaModalOpen(true)} hitSlop={12} style={styles.ledWrap} accessibilityLabel="Status do WhatsApp">
        <Animated.View style={[styles.led, { backgroundColor: ledColor, shadowColor: ledColor, opacity: glow }]} />
      </Pressable>
      <Pressable onPress={() => navigation.openDrawer()} hitSlop={12} accessibilityLabel="Abrir menu">
        <Ionicons name="menu" size={30} color={colors.text} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingBottom: 10,
    backgroundColor: colors.bg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: { flex: 1, color: colors.text, fontSize: 19, fontWeight: '700' },
  ledWrap: { padding: 6 },
  led: {
    width: 14, height: 14, borderRadius: 7,
    shadowOpacity: 1, shadowRadius: 8, shadowOffset: { width: 0, height: 0 }, elevation: 6,
  },
});
