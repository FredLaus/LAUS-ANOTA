// Pequenos componentes visuais reutilizados nas telas de configuração.
import React from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius } from '../theme';

export function Section({ title, children }) {
  return (
    <View style={styles.section}>
      {!!title && <Text style={styles.sectionTitle}>{title}</Text>}
      {children}
    </View>
  );
}

export function Field({ label, ...props }) {
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput style={styles.input} placeholderTextColor={colors.muted} {...props} />
    </View>
  );
}

export function Button({ title, onPress, ghost }) {
  return (
    <Pressable onPress={onPress} style={[styles.btn, ghost && styles.btnGhost]}>
      <Text style={[styles.btnText, ghost && { color: colors.neon }]}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  section: { backgroundColor: colors.card, borderRadius: radius.md, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: colors.border },
  sectionTitle: { color: colors.neon, fontWeight: '800', fontSize: 13, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 12 },
  label: { color: colors.muted, marginBottom: 6, fontWeight: '600' },
  input: { backgroundColor: colors.bg, color: colors.text, borderRadius: radius.sm, padding: 12, borderWidth: 1, borderColor: colors.border },
  btn: { backgroundColor: colors.neon, borderRadius: radius.md, paddingVertical: 14, alignItems: 'center', marginTop: 4 },
  btnGhost: { backgroundColor: 'transparent', borderWidth: 1, borderColor: colors.neon },
  btnText: { color: '#000', fontWeight: '800', fontSize: 15 },
});
