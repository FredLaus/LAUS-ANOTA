// Campainha de delivery em loop para novos pedidos em "Em Análise".
import { Audio } from 'expo-av';

let sound = null;
let wanted = false;

export async function startAlarm() {
  if (wanted) return;
  wanted = true;
  try {
    await Audio.setAudioModeAsync({
      playsInSilentModeIOS: true,
      staysActiveInBackground: true,
      shouldDuckAndroid: false,
    });
    const { sound: s } = await Audio.Sound.createAsync(require('../../assets/alert.wav'), {
      isLooping: true,
      volume: 1.0,
      shouldPlay: true,
    });
    if (!wanted) {
      // foi cancelado enquanto carregava
      await s.unloadAsync();
      return;
    }
    sound = s;
  } catch (e) {
    wanted = false;
    console.warn('Falha ao tocar alarme:', e);
  }
}

export async function stopAlarm() {
  wanted = false;
  const s = sound;
  sound = null;
  if (s) {
    try {
      await s.stopAsync();
      await s.unloadAsync();
    } catch (e) {
      // ignora
    }
  }
}
