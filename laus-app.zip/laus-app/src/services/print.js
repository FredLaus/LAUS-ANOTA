// Impressão de comprovante via diálogo de impressão do sistema.
import * as Print from 'expo-print';
import { fmtMoney } from '../utils';

const esc = (s) => String(s ?? '').replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

export async function printOrder(order, settings) {
  const mm = settings.print_width === '58' ? 58 : 80;
  const copies = Math.min(5, Math.max(1, parseInt(settings.print_copies, 10) || 1));
  const via = `
    <div style="page-break-after:always">
      <h3 style="text-align:center">${esc(settings.print_header)}</h3>
      <p style="text-align:center">${esc(settings.rest_name)}</p><hr/>
      <p><b>PEDIDO #${esc(order.number)}</b><br/>${esc(order.customer)}</p>
      ${order.items.map((i) => `<p>${esc(i.qty)}x ${esc(i.name)}</p>`).join('')}
      ${order.notes ? `<p>Obs: ${esc(order.notes)}</p>` : ''}<hr/>
      <p><b>Total: ${fmtMoney(order.total)}</b> (${esc(order.payment)})</p>
    </div>`;
  const html = `<html><body style="width:${mm}mm;font-family:monospace;font-size:13px">${via.repeat(copies)}</body></html>`;
  await Print.printAsync({ html, width: mm * 2.83 });
}
