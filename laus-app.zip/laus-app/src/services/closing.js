// Fechamento diário às 06:30: soma os pedidos finalizados nas últimas 24h e
// grava no histórico mensal (tabela daily_revenue).
import * as D from '../db';
import { dateKey, latestDue } from '../utils';
import { CLOSING_HOUR, CLOSING_MIN } from '../config';

const DAY = 86400000;

// Processa UM fechamento. runAt = instante (Date) em que o fechamento roda (06:30).
// O faturamento é gravado na data da noite/dia anterior.
export async function runClosingFor(runAt) {
  const end = runAt.getTime();
  const { total, count } = await D.sumFinishedBetween(end - DAY, end);
  const revenueDate = new Date(end - DAY);
  await D.upsertRevenue(dateKey(revenueDate), total, count);
  return { date: dateKey(revenueDate), total, count };
}

// "Cron simulado": chamado ao abrir o app, ao voltar para o primeiro plano
// e a cada minuto. Recupera fechamentos perdidos (app fechado às 06:30).
export async function runPendingClosings(now = new Date()) {
  const settings = await D.getSettings();
  const due = latestDue(now);
  let cursor;
  if (settings.last_closing) {
    const [y, m, d] = settings.last_closing.split('-').map(Number);
    cursor = new Date(y, m - 1, d + 1, CLOSING_HOUR, CLOSING_MIN, 0, 0);
  } else {
    cursor = new Date(due);
  }
  let ran = 0;
  while (cursor <= due && ran < 31) {
    await runClosingFor(cursor);
    await D.setSetting('last_closing', dateKey(cursor));
    cursor = new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() + 1, CLOSING_HOUR, CLOSING_MIN);
    ran++;
  }
  return ran;
}

// Botão "Rodar fechamento agora": recalcula o último período concluído.
export async function forceClosing() {
  const due = latestDue(new Date());
  const r = await runClosingFor(due);
  await D.setSetting('last_closing', dateKey(due));
  return r;
}
