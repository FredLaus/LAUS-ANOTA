// Notificações locais (push local, sem servidor) para pedidos atrasados.
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function setupNotifications() {
  try {
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('atrasos', {
        name: 'Pedidos atrasados',
        importance: Notifications.AndroidImportance.MAX,
        sound: 'default',
        vibrationPattern: [0, 600, 300, 600, 300, 600],
        enableVibrate: true,
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      });
    }
    const { status } = await Notifications.getPermissionsAsync();
    if (status !== 'granted') await Notifications.requestPermissionsAsync();
  } catch (e) {
    console.warn('Notificações indisponíveis:', e);
  }
}

// Agenda a notificação para o exato momento em que o cronômetro zera.
// Retorna o id da notificação (para cancelar depois) ou null.
export async function scheduleLate(order, dueAtMs) {
  try {
    const seconds = Math.max(1, Math.round((dueAtMs - Date.now()) / 1000));
    return await Notifications.scheduleNotificationAsync({
      content: {
        title: '⚠️ Pedido atrasado',
        body: `Atenção! O pedido #${order.number} do cliente ${order.customer} está atrasado! Verifique a produção.`,
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.MAX,
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
        seconds,
        channelId: 'atrasos',
      },
    });
  } catch (e) {
    console.warn('Falha ao agendar notificação:', e);
    return null;
  }
}

export async function cancelScheduled(id) {
  if (!id) return;
  try {
    await Notifications.cancelScheduledNotificationAsync(id);
  } catch (e) {
    // ignora
  }
}
