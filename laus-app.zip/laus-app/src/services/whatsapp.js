// Comunicação com o robô local de automação do WhatsApp.
//
// Contrato esperado do robô (HTTP/JSON, na rede local do restaurante):
//   GET  {bot_url}/status          -> { "connected": true|false }
//   GET  {bot_url}/qr              -> { "qr": "texto-do-qr" }  (quando desconectado)
//   POST {bot_url}/reconnect       -> reinicia a sessão do WhatsApp
//   GET  {bot_url}/orders/pending  -> [{ externalId, customer, items:[{name,qty}], notes, payment, total }]
//   POST {bot_url}/orders/ack      -> body { ids: [externalId, ...] } confirma recebimento

async function request(url, options = {}, timeoutMs = 4000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json().catch(() => ({}));
  } finally {
    clearTimeout(t);
  }
}

const base = (u) => String(u || '').trim().replace(/\/+$/, '');

export async function fetchStatus(botUrl) {
  if (!base(botUrl)) return false;
  try {
    const r = await request(`${base(botUrl)}/status`);
    return r.connected === true;
  } catch {
    return false;
  }
}

export async function fetchQr(botUrl) {
  if (!base(botUrl)) return null;
  try {
    const r = await request(`${base(botUrl)}/qr`);
    return r.qr || null;
  } catch {
    return null;
  }
}

export async function reconnect(botUrl) {
  if (!base(botUrl)) throw new Error('Robô não configurado');
  await request(`${base(botUrl)}/reconnect`, { method: 'POST' });
}

export async function fetchPendingOrders(botUrl) {
  try {
    const r = await request(`${base(botUrl)}/orders/pending`);
    return Array.isArray(r) ? r : [];
  } catch {
    return [];
  }
}

export async function ackOrders(botUrl, ids) {
  try {
    await request(`${base(botUrl)}/orders/ack`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    });
  } catch {
    // o robô reenviará; o app ignora duplicados pelo externalId
  }
}
