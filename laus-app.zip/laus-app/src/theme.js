// Paleta LAUS: preto puro + azul marinho + destaque neon/ciano
export const colors = {
  bg: '#000000',
  card: '#0A192F',
  card2: '#1E293B',
  border: '#1F2F4A',
  text: '#FFFFFF',
  muted: '#94A3B8',
  neon: '#00E5FF',
  blue: '#2D7FF9',
  green: '#22C55E',
  yellow: '#FACC15',
  red: '#EF4444',
  off: '#374151',
};

export const radius = { sm: 8, md: 14, lg: 20 };
