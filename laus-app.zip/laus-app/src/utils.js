import { CLOSING_HOUR, CLOSING_MIN } from './config';

export const pad = (n) => String(n).padStart(2, '0');

// 'YYYY-MM-DD' no horário local
export const dateKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

// Formata número como moeda brasileira: R$ 1.234,50
export function fmtMoney(n) {
  const v = Number(n) || 0;
  const [int, dec] = Math.abs(v).toFixed(2).split('.');
  const withDots = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${v < 0 ? '-' : ''}R$ ${withDots},${dec}`;
}

// Converte texto digitado ("12,90") em número; retorna null se inválido
export function parseMoney(text) {
  const n = parseFloat(String(text).replace(/\./g, '').replace(',', '.'));
  return Number.isFinite(n) && n >= 0 ? n : null;
}

// Último momento de fechamento (06:30) que já passou
export function latestDue(now = new Date()) {
  const t = new Date(now);
  t.setHours(CLOSING_HOUR, CLOSING_MIN, 0, 0);
  if (now < t) t.setDate(t.getDate() - 1);
  return t;
}

export function fmtDateTime(ms) {
  const d = new Date(ms);
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// Informações do cronômetro regressivo de um pedido.
// Verde nos primeiros 10 min decorridos (ou metade do limite, se menor),
// amarelo depois disso, vermelho piscando ao zerar.
export function timerInfo(order, now, colors) {
  const limit = order.timer_limit_min * 60000;
  const elapsed = now - order.timer_start;
  const remaining = limit - elapsed;
  const greenUntil = Math.min(10 * 60000, limit / 2);
  let color = elapsed < greenUntil ? colors.green : colors.yellow;
  if (remaining <= 0) color = colors.red;
  return { remaining, color, late: remaining <= 0 };
}

export function fmtClock(ms) {
  const s = Math.floor(Math.abs(ms) / 1000);
  return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
}
