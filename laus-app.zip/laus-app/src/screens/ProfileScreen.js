// Aba "Você" / Perfil do Restaurante.
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import TopBar from '../components/TopBar';
import Logo from '../components/Logo';
import { Button, Field, Section } from '../components/Ui';
import { colors } from '../theme';
import { useApp } from '../context/AppContext';
import { APP_NAME, TAGLINE } from '../config';

export default function ProfileScreen() {
  const { settings, setSetting } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  useEffect(() => {
    setName(settings.rest_name || '');
    setPhone(settings.rest_phone || '');
    setAddress(settings.rest_address || '');
  }, [settings.rest_name, settings.rest_phone, settings.rest_address]);

  const save = async () => {
    await setSetting('rest_name', name.trim() || 'Meu Restaurante');
    await setSetting('rest_phone', phone.trim());
    await setSetting('rest_address', address.trim());
    Alert.alert('Perfil salvo', 'Os dados do restaurante foram atualizados.');
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <TopBar title="Perfil do Restaurante" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        <View style={styles.hero}>
          <Logo size={80} />
          <Text style={styles.name}>{settings.rest_name}</Text>
          <Text style={styles.tag}>{APP_NAME} • {TAGLINE}</Text>
        </View>
        <Section title="Dados do restaurante">
          <Field label="Nome" value={name} onChangeText={setName} />
          <Field label="Telefone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
          <Field label="Endereço" value={address} onChangeText={setAddress} multiline />
          <Button title="Salvar perfil" onPress={save} />
        </Section>
        <Text style={styles.free}>App 100% gratuito • sem mensalidade • dados guardados só neste aparelho.</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: { alignItems: 'center', marginBottom: 20 },
  name: { color: colors.text, fontSize: 22, fontWeight: '800', marginTop: 10 },
  tag: { color: colors.neon, marginTop: 4 },
  free: { color: colors.muted, textAlign: 'center', fontSize: 12 },
});
