// Aba Cardápio (Modo Patrão): categorias, edição rápida, formulário e chave de disponibilidade.
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, FlatList, Image, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView,
  StyleSheet, Switch, Text, TextInput, View,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import TopBar from '../components/TopBar';
import { colors, radius } from '../theme';
import { useApp } from '../context/AppContext';
import { fmtMoney, parseMoney } from '../utils';

const BASE_CATEGORIES = ['Hambúrgueres', 'Bebidas', 'Sobremesas', 'Combos'];

// Texto que vira campo editável ao toque e salva ao sair/confirmar
function EditableText({ value, onSave, style, keyboardType, format }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(String(value));
  useEffect(() => setText(String(value)), [value]);

  const commit = () => {
    setEditing(false);
    if (text.trim() !== String(value)) onSave(text.trim());
  };

  if (editing) {
    return (
      <TextInput
        autoFocus value={text} onChangeText={setText} onBlur={commit} onSubmitEditing={commit}
        keyboardType={keyboardType} style={[style, styles.inlineInput]} selectTextOnFocus
      />
    );
  }
  return (
    <Pressable onPress={() => setEditing(true)}>
      <Text style={style}>{format ? format(value) : value}</Text>
    </Pressable>
  );
}

function ItemRow({ item, onEdit }) {
  const { patchItem } = useApp();
  const on = item.available === 1;

  return (
    <View style={styles.row}>
      {/* Conteúdo esmaecido quando indisponível; a chave e o botão Editar continuam nítidos */}
      <View style={[styles.rowMain, !on && { opacity: 0.35 }]}>
        {item.photo ? (
          <Image source={{ uri: item.photo }} style={styles.photo} />
        ) : (
          <View style={[styles.photo, styles.photoEmpty]}><Text style={{ fontSize: 26 }}>🍽️</Text></View>
        )}
        <View style={{ flex: 1 }}>
          <EditableText
            value={item.name} style={styles.name}
            onSave={(v) => v && patchItem(item.id, { name: v })}
          />
          <Text style={styles.desc} numberOfLines={2}>{item.description}</Text>
          <EditableText
            value={item.price} style={styles.price} keyboardType="decimal-pad" format={fmtMoney}
            onSave={(v) => {
              const n = parseMoney(v);
              if (n === null) Alert.alert('Preço inválido', 'Digite um valor como 12,90.');
              else patchItem(item.id, { price: n });
            }}
          />
          {!on && <Text style={styles.unavail}>Indisponível</Text>}
        </View>
      </View>
      <View style={styles.side}>
        <Switch
          value={on}
          onValueChange={(v) => patchItem(item.id, { available: v ? 1 : 0 })}
          trackColor={{ false: colors.off, true: colors.neon }}
          thumbColor={on ? '#fff' : '#9CA3AF'}
        />
        <Pressable onPress={() => onEdit(item)} style={styles.editBtn}>
          <Text style={styles.editText}>Editar</Text>
        </Pressable>
      </View>
    </View>
  );
}

function ItemForm({ visible, item, categories, onClose }) {
  const { saveItem, removeItem } = useApp();
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [desc, setDesc] = useState('');
  const [category, setCategory] = useState(BASE_CATEGORIES[0]);
  const [newCat, setNewCat] = useState('');
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    if (!visible) return;
    setName(item?.name || '');
    setPrice(item ? String(item.price).replace('.', ',') : '');
    setDesc(item?.description || '');
    setCategory(item?.category || categories[0] || BASE_CATEGORIES[0]);
    setNewCat('');
    setPhoto(item?.photo || null);
  }, [visible, item, categories]);

  const pickPhoto = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.6, allowsEditing: true, aspect: [1, 1] });
    if (!res.canceled) setPhoto(res.assets[0].uri);
  };

  const submit = async () => {
    const p = parseMoney(price);
    const cat = (newCat.trim() || category).trim();
    if (!name.trim()) return Alert.alert('Informe o nome do item.');
    if (p === null) return Alert.alert('Preço inválido', 'Digite um valor como 12,90.');
    await saveItem({ id: item?.id, name: name.trim(), price: p, description: desc.trim(), category: cat, photo });
    onClose();
  };

  const confirmDelete = () =>
    Alert.alert('Excluir item', `Excluir "${item.name}" do cardápio?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Excluir', style: 'destructive', onPress: async () => { await removeItem(item.id); onClose(); } },
    ]);

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.backdrop}>
        <View style={styles.sheet}>
          <ScrollView keyboardShouldPersistTaps="handled">
            <Text style={styles.sheetTitle}>{item ? 'Editar item' : 'Adicionar novo item'}</Text>

            <Pressable onPress={pickPhoto} style={styles.photoPick}>
              {photo ? <Image source={{ uri: photo }} style={styles.photoPickImg} /> : <Text style={{ color: colors.neon }}>📷 Escolher foto</Text>}
            </Pressable>

            <Text style={styles.label}>Nome</Text>
            <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Ex.: X-Burger" placeholderTextColor={colors.muted} />
            <Text style={styles.label}>Preço (R$)</Text>
            <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="decimal-pad" placeholder="0,00" placeholderTextColor={colors.muted} />
            <Text style={styles.label}>Descrição</Text>
            <TextInput style={[styles.input, { height: 80, textAlignVertical: 'top' }]} value={desc} onChangeText={setDesc} multiline placeholder="Ingredientes, tamanho…" placeholderTextColor={colors.muted} />
            <Text style={styles.label}>Categoria</Text>
            <View style={styles.catWrap}>
              {categories.map((c) => (
                <Pressable key={c} onPress={() => { setCategory(c); setNewCat(''); }} style={[styles.catChip, category === c && !newCat && styles.catChipOn]}>
                  <Text style={[styles.catText, category === c && !newCat && { color: '#000' }]}>{c}</Text>
                </Pressable>
              ))}
            </View>
            <TextInput style={styles.input} value={newCat} onChangeText={setNewCat} placeholder="Ou digite uma nova categoria" placeholderTextColor={colors.muted} />

            <Pressable style={styles.save} onPress={submit}><Text style={styles.saveText}>Salvar</Text></Pressable>
            {item && <Pressable style={styles.del} onPress={confirmDelete}><Text style={styles.delText}>Excluir item</Text></Pressable>}
            <Pressable style={styles.cancel} onPress={onClose}><Text style={styles.cancelText}>Cancelar</Text></Pressable>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

export default function MenuScreen() {
  const { menu } = useApp();
  const [cat, setCat] = useState('Todos');
  const [form, setForm] = useState({ open: false, item: null });

  const categories = useMemo(() => {
    const extra = menu.map((m) => m.category).filter((c) => !BASE_CATEGORIES.includes(c));
    return [...BASE_CATEGORIES, ...Array.from(new Set(extra))];
  }, [menu]);

  const data = cat === 'Todos' ? menu : menu.filter((m) => m.category === cat);

  const addBtn = (
    <Pressable onPress={() => setForm({ open: true, item: null })} hitSlop={8} style={styles.addBtn} accessibilityLabel="Adicionar novo item">
      <Text style={styles.addText}>＋</Text>
    </Pressable>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <TopBar title="Cardápio" right={addBtn} />
      <View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          {['Todos', ...categories].map((c) => (
            <Pressable key={c} onPress={() => setCat(c)} style={[styles.catChip, cat === c && styles.catChipOn]}>
              <Text style={[styles.catText, cat === c && { color: '#000' }]}>{c}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>
      <FlatList
        data={data}
        keyExtractor={(i) => String(i.id)}
        contentContainerStyle={{ padding: 16 }}
        renderItem={({ item }) => <ItemRow item={item} onEdit={(it) => setForm({ open: true, item: it })} />}
        ListEmptyComponent={<Text style={styles.empty}>Nenhum item nesta categoria. Toque em ＋ para adicionar.</Text>}
      />
      <ItemForm visible={form.open} item={form.item} categories={categories} onClose={() => setForm({ open: false, item: null })} />
    </View>
  );
}

const styles = StyleSheet.create({
  addBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.neon, alignItems: 'center', justifyContent: 'center' },
  addText: { color: '#000', fontSize: 22, fontWeight: '800', marginTop: -2 },
  chips: { paddingHorizontal: 16, paddingVertical: 12, gap: 8 },
  catWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  catChip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 999, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  catChipOn: { backgroundColor: colors.neon, borderColor: colors.neon },
  catText: { color: colors.text, fontWeight: '700' },
  empty: { color: colors.muted, textAlign: 'center', marginTop: 60 },
  row: { flexDirection: 'row', backgroundColor: colors.card2, borderRadius: radius.md, padding: 12, marginBottom: 12, alignItems: 'center' },
  rowMain: { flex: 1, flexDirection: 'row', gap: 12, alignItems: 'center' },
  photo: { width: 64, height: 64, borderRadius: radius.sm },
  photoEmpty: { backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center' },
  name: { color: colors.text, fontWeight: '700', fontSize: 16 },
  desc: { color: colors.muted, fontSize: 13, marginVertical: 2 },
  price: { color: colors.green, fontWeight: '800', fontSize: 16 },
  unavail: { color: colors.red, fontSize: 12, fontWeight: '700', marginTop: 2 },
  inlineInput: { borderBottomWidth: 1, borderBottomColor: colors.neon, padding: 0, minWidth: 80 },
  side: { alignItems: 'center', gap: 8, marginLeft: 8 },
  editBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.neon },
  editText: { color: colors.neon, fontWeight: '700', fontSize: 13 },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.75)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: colors.card, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, padding: 20, maxHeight: '92%' },
  sheetTitle: { color: colors.text, fontSize: 20, fontWeight: '800', marginBottom: 12 },
  photoPick: { height: 110, borderRadius: radius.md, borderWidth: 1, borderStyle: 'dashed', borderColor: colors.neon, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 8 },
  photoPickImg: { width: '100%', height: '100%' },
  label: { color: colors.muted, marginTop: 10, marginBottom: 6, fontWeight: '600' },
  input: { backgroundColor: colors.bg, color: colors.text, borderRadius: radius.sm, padding: 12, borderWidth: 1, borderColor: colors.border },
  save: { backgroundColor: colors.neon, borderRadius: radius.md, paddingVertical: 14, alignItems: 'center', marginTop: 18 },
  saveText: { color: '#000', fontWeight: '800', fontSize: 16 },
  del: { paddingVertical: 12, alignItems: 'center' },
  delText: { color: colors.red, fontWeight: '700' },
  cancel: { paddingVertical: 10, alignItems: 'center', marginBottom: 10 },
  cancelText: { color: colors.muted, fontWeight: '600' },
});
