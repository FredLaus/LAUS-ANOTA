// Configurações Gerais: tempo de alerta, som, endereço do robô e dados.
import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import TopBar from '../components/TopBar';
import { Button, Field, Section } from '../components/Ui';
import { colors, radius } from '../theme';
import { useApp } from '../context/AppContext';

export default function SettingsScreen() {
  const { settings, setSetting, clearDemo, refreshBot } = useApp();
  const [minutes, setMinutes] = useState('20');
  const [botUrl, setBotUrl] = useState('');

  useEffect(() => {
    setMinutes(settings.timer_limit_min || '20');
    setBotUrl(settings.bot_url || '');
  }, [settings.timer_limit_min, settings.bot_url]);

  const saveMinutes = async (val) => {
    const n = parseInt(val, 10);
    if (!Number.isFinite(n) || n < 1 || n > 600) return Alert.alert('Valor inválido', 'Informe de 1 a 600 minutos.');
    await setSetting('timer_limit_min', n);
    setMinutes(String(n));
    Alert.alert('Salvo', `Novos pedidos usarão ${n} minutos. Pedidos já em andamento mantêm o tempo original.`);
  };

  const saveBot = async () => {
    await setSetting('bot_url', botUrl.trim());
    setTimeout(refreshBot, 200);
    Alert.alert('Salvo', 'Endereço do robô atualizado.');
  };

  const confirmClear = () =>
    Alert.alert('Limpar dados de demonstração', 'Apaga todos os pedidos, itens do cardápio e faturamento. Continuar?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Apagar tudo', style: 'destructive', onPress: clearDemo },
    ]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <TopBar title="Configurações Gerais" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        <Section title="Tempo de Alerta de Produção">
          <Field label="Limite do cronômetro (minutos)" value={minutes} onChangeText={setMinutes} keyboardType="number-pad" />
          <View style={styles.chips}>
            {[20, 30, 40, 60].map((n) => (
              <Pressable key={n} style={[styles.chip, minutes === String(n) && styles.chipOn]} onPress={() => setMinutes(String(n))}>
                <Text style={[styles.chipText, minutes === String(n) && { color: '#000' }]}>{n} min</Text>
              </Pressable>
            ))}
          </View>
          <Button title="Salvar tempo" onPress={() => saveMinutes(minutes)} />
        </Section>

        <Section title="Som de novos pedidos">
          <View style={styles.row}>
            <Text style={styles.rowText}>Campainha contínua em "Em Análise"</Text>
            <Switch
              value={settings.alarm_enabled !== '0'}
              onValueChange={(v) => setSetting('alarm_enabled', v ? '1' : '0')}
              trackColor={{ false: colors.off, true: colors.neon }} thumbColor="#fff"
            />
          </View>
        </Section>

        <Section title="Robô do WhatsApp">
          <Field
            label="Endereço do robô na rede local" value={botUrl} onChangeText={setBotUrl}
            placeholder="http://192.168.0.10:3000" autoCapitalize="none" autoCorrect={false} keyboardType="url"
          />
          <Button title="Salvar endereço" onPress={saveBot} />
        </Section>

        <Section title="Dados">
          <Button title="Limpar dados de demonstração" ghost onPress={confirmClear} />
          <Text style={styles.note}>LAUS é 100% gratuito. Todos os dados ficam guardados somente neste aparelho.</Text>
        </Section>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  chips: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  chip: { flex: 1, paddingVertical: 10, borderRadius: radius.sm, backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.border, alignItems: 'center' },
  chipOn: { backgroundColor: colors.neon, borderColor: colors.neon },
  chipText: { color: colors.text, fontWeight: '700' },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  rowText: { color: colors.text, flex: 1 },
  note: { color: colors.muted, fontSize: 12, marginTop: 12, textAlign: 'center' },
});
