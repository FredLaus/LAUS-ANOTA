// FATURAMENTO DA NOITE: último fechamento (06:30), gráfico mensal e comparativo com o mês passado.
import React, { useMemo, useState } from 'react';
import { Alert, Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { BarChart, LineChart } from 'react-native-chart-kit';
import { Ionicons } from '@expo/vector-icons';
import TopBar from '../components/TopBar';
import { colors, radius } from '../theme';
import { useApp } from '../context/AppContext';
import { fmtMoney, pad } from '../utils';

const MONTHS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

const chartConfig = {
  backgroundGradientFrom: colors.card,
  backgroundGradientTo: colors.card,
  decimalPlaces: 0,
  color: (o = 1) => `rgba(0, 229, 255, ${o})`,
  labelColor: (o = 1) => `rgba(255, 255, 255, ${o})`,
  propsForDots: { r: '3', strokeWidth: '1', stroke: colors.neon },
  propsForBackgroundLines: { stroke: colors.border },
  barPercentage: 0.45,
};

export default function RevenueScreen() {
  const { revenue, closeNow } = useApp();
  const [mode, setMode] = useState('line');
  const width = Dimensions.get('window').width - 32;

  const stats = useMemo(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth();
    const key = (yy, mm, dd) => `${yy}-${pad(mm + 1)}-${pad(dd)}`;
    const byDate = Object.fromEntries(revenue.map((r) => [r.date, r.total]));
    const days = new Date(y, m + 1, 0).getDate();
    const series = Array.from({ length: days }, (_, i) => byDate[key(y, m, i + 1)] || 0);
    const labels = series.map((_, i) => ((i + 1) % 5 === 0 || i === 0 ? String(i + 1) : ''));

    const cut = now.getDate(); // mesmo período: dias 1..hoje
    const pm = new Date(y, m - 1, 1);
    let cur = 0;
    let prev = 0;
    for (let d = 1; d <= cut; d++) {
      cur += byDate[key(y, m, d)] || 0;
      prev += byDate[key(pm.getFullYear(), pm.getMonth(), d)] || 0;
    }
    const monthTotal = series.reduce((a, b) => a + b, 0);
    const last = revenue.length ? revenue[revenue.length - 1] : null;
    const pct = prev > 0 ? ((cur - prev) / prev) * 100 : null;
    return { series, labels, cur, prev, pct, monthTotal, last, monthName: MONTHS[m] };
  }, [revenue]);

  const up = stats.pct !== null && stats.pct >= 0;
  const hasData = stats.series.some((v) => v > 0);
  const data = { labels: stats.labels, datasets: [{ data: stats.series }] };

  const runNow = async () => {
    const r = await closeNow();
    Alert.alert('Fechamento concluído', `${r.count} pedidos finalizados somando ${fmtMoney(r.total)}.`);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <TopBar title="Faturamento da Noite" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        {/* Painel principal */}
        <View style={styles.hero}>
          <Text style={styles.heroLabel}>Faturamento da Última Noite</Text>
          <Text style={styles.heroValue}>{fmtMoney(stats.last ? stats.last.total : 0)}</Text>
          <Text style={styles.heroSub}>
            {stats.last
              ? `${stats.last.date.split('-').reverse().join('/')} • ${stats.last.orders_count} pedidos • fechamento diário às 06:30`
              : 'Aguardando o primeiro fechamento das 06:30'}
          </Text>
        </View>

        {/* Comparativo */}
        <View style={[styles.insight, { borderColor: stats.pct === null ? colors.border : up ? colors.green : colors.red }]}>
          <Ionicons
            name={stats.pct === null ? 'remove' : up ? 'arrow-up-circle' : 'arrow-down-circle'}
            size={34}
            color={stats.pct === null ? colors.muted : up ? colors.green : colors.red}
          />
          <View style={{ flex: 1 }}>
            <Text style={styles.insightTitle}>Comparativo inteligente</Text>
            <Text style={[styles.insightText, { color: stats.pct === null ? colors.muted : up ? colors.green : colors.red }]}>
              {stats.pct === null
                ? 'Sem dados do mês passado para comparar'
                : `${up ? '+' : ''}${stats.pct.toFixed(0)}% de faturamento este mês`}
            </Text>
            {stats.pct !== null && (
              <Text style={styles.insightSub}>
                {fmtMoney(stats.cur)} agora vs {fmtMoney(stats.prev)} no mesmo período do mês passado
              </Text>
            )}
          </View>
        </View>

        {/* Gráfico mensal */}
        <View style={styles.chartHead}>
          <Text style={styles.section}>{stats.monthName} — {fmtMoney(stats.monthTotal)}</Text>
          <View style={styles.toggle}>
            {[['line', 'Linhas'], ['bar', 'Barras']].map(([k, l]) => (
              <Pressable key={k} onPress={() => setMode(k)} style={[styles.toggleBtn, mode === k && { backgroundColor: colors.neon }]}>
                <Text style={[styles.toggleText, mode === k && { color: '#000' }]}>{l}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {hasData ? (
          <View style={styles.chartBox}>
            {mode === 'line' ? (
              <LineChart
                data={data} width={width} height={240} chartConfig={chartConfig} bezier fromZero
                yAxisLabel="R$ " withInnerLines style={styles.chart}
                formatYLabel={(v) => String(Math.round(Number(v)))}
              />
            ) : (
              <BarChart
                data={data} width={width} height={240} chartConfig={chartConfig} fromZero
                yAxisLabel="R$ " yAxisSuffix="" showValuesOnTopOfBars={false} style={styles.chart}
              />
            )}
            <Text style={styles.axisNote}>Dias do mês (eixo X) × valores em R$ (eixo Y)</Text>
          </View>
        ) : (
          <Text style={styles.empty}>Ainda não há faturamento registrado neste mês.</Text>
        )}

        <Pressable style={styles.runBtn} onPress={runNow}>
          <Text style={styles.runText}>Rodar fechamento agora</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: { backgroundColor: colors.card, borderRadius: radius.lg, padding: 22, borderWidth: 1, borderColor: colors.neon, alignItems: 'center' },
  heroLabel: { color: colors.muted, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', fontSize: 12 },
  heroValue: { color: colors.green, fontSize: 42, fontWeight: '900', marginVertical: 8 },
  heroSub: { color: colors.muted, fontSize: 12, textAlign: 'center' },
  insight: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.card2, borderRadius: radius.md, padding: 16, marginTop: 14, borderWidth: 1 },
  insightTitle: { color: colors.neon, fontSize: 12, fontWeight: '800', letterSpacing: 1, textTransform: 'uppercase' },
  insightText: { fontSize: 18, fontWeight: '800', marginTop: 2 },
  insightSub: { color: colors.muted, fontSize: 12, marginTop: 4 },
  chartHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 22, marginBottom: 10 },
  section: { color: colors.text, fontWeight: '800', fontSize: 16, flex: 1 },
  toggle: { flexDirection: 'row', backgroundColor: colors.card, borderRadius: 999, borderWidth: 1, borderColor: colors.border },
  toggleBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999 },
  toggleText: { color: colors.text, fontWeight: '700', fontSize: 13 },
  chartBox: { backgroundColor: colors.card, borderRadius: radius.md, overflow: 'hidden', borderWidth: 1, borderColor: colors.border },
  chart: { borderRadius: radius.md },
  axisNote: { color: colors.muted, fontSize: 11, textAlign: 'center', paddingBottom: 8 },
  empty: { color: colors.muted, textAlign: 'center', marginVertical: 30 },
  runBtn: { marginTop: 22, borderWidth: 1, borderColor: colors.neon, borderRadius: radius.md, paddingVertical: 13, alignItems: 'center' },
  runText: { color: colors.neon, fontWeight: '700' },
});
