// Suporte Integrado: contato direto e perguntas frequentes.
import React, { useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import TopBar from '../components/TopBar';
import { Button, Section } from '../components/Ui';
import { colors, radius } from '../theme';
import { SUPPORT } from '../config';

const FAQ = [
  ['Como aceito um pedido e paro o som?', 'Na aba Pedidos > Em Análise, toque em "Aceitar Pedido". O alarme só para quando não houver mais pedidos em análise.'],
  ['Como mudo o tempo do cronômetro?', 'Menu ☰ > Configurações Gerais > Tempo de Alerta de Produção. Vale para os próximos pedidos.'],
  ['O que significa o LED no topo?', 'Verde: robô do WhatsApp conectado. Vermelho: desconectado. Toque nele para reconectar.'],
  ['Quando o faturamento é calculado?', 'Todo dia às 06:30, somando os pedidos finalizados nas últimas 24 horas.'],
  ['O app tem mensalidade?', 'Não. O LAUS é gratuito e guarda tudo no próprio aparelho.'],
];

function Faq({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <Pressable onPress={() => setOpen(!open)} style={styles.faq}>
      <View style={styles.faqHead}>
        <Text style={styles.q}>{q}</Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={18} color={colors.neon} />
      </View>
      {open && <Text style={styles.a}>{a}</Text>}
    </Pressable>
  );
}

export default function SupportScreen() {
  const open = async (url) => {
    try {
      await Linking.openURL(url);
    } catch {
      Alert.alert('Não foi possível abrir', 'Tente novamente ou use outro canal de contato.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <TopBar title="Suporte Integrado" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        <Section title="Fale com a LAUS">
          <Button title="Chamar no WhatsApp" onPress={() => open(`https://wa.me/${SUPPORT.whatsapp}`)} />
          <Button title="Enviar e-mail" ghost onPress={() => open(`mailto:${SUPPORT.email}`)} />
        </Section>
        <Section title="Perguntas frequentes">
          {FAQ.map(([q, a]) => <Faq key={q} q={q} a={a} />)}
        </Section>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  faq: { backgroundColor: colors.card2, borderRadius: radius.sm, padding: 14, marginBottom: 8 },
  faqHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  q: { color: colors.text, fontWeight: '700', flex: 1 },
  a: { color: colors.muted, marginTop: 8, lineHeight: 20 },
});
