// Histórico de Pedidos com busca em tempo real (nome do cliente ou nº do pedido) no SQLite.
import React, { useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import TopBar from '../components/TopBar';
import { colors, radius } from '../theme';
import * as D from '../db';
import { fmtDateTime, fmtMoney } from '../utils';

const FILTERS = [
  { key: null, label: 'Todos' },
  { key: 'finalizado', label: 'Finalizados' },
  { key: 'cancelado', label: 'Cancelados' },
];

export default function HistoryScreen() {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState(null);
  const [rows, setRows] = useState([]);

  // Refaz a consulta a cada letra digitada
  useEffect(() => {
    let alive = true;
    D.searchHistory(query, filter).then((r) => alive && setRows(r));
    return () => { alive = false; };
  }, [query, filter]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <TopBar title="Histórico de Pedidos" />
      <View style={styles.search}>
        <Ionicons name="search" size={20} color={colors.muted} />
        <TextInput
          style={styles.input} value={query} onChangeText={setQuery}
          placeholder="Buscar por cliente ou nº do pedido" placeholderTextColor={colors.muted}
          autoCorrect={false}
        />
        {!!query && (
          <Pressable onPress={() => setQuery('')} hitSlop={8}>
            <Ionicons name="close-circle" size={20} color={colors.muted} />
          </Pressable>
        )}
      </View>
      <View style={styles.filters}>
        {FILTERS.map((f) => (
          <Pressable key={String(f.key)} onPress={() => setFilter(f.key)} style={[styles.chip, filter === f.key && styles.chipOn]}>
            <Text style={[styles.chipText, filter === f.key && { color: '#000' }]}>{f.label}</Text>
          </Pressable>
        ))}
      </View>
      <FlatList
        data={rows}
        keyExtractor={(o) => String(o.id)}
        contentContainerStyle={{ padding: 16 }}
        ListEmptyComponent={<Text style={styles.empty}>Nenhum pedido encontrado.</Text>}
        renderItem={({ item: o }) => (
          <View style={styles.card}>
            <View style={styles.head}>
              <Text style={styles.number}>#{o.number}</Text>
              <Text style={[styles.status, { color: o.status === 'finalizado' ? colors.green : colors.red }]}>
                {o.status === 'finalizado' ? 'Finalizado' : 'Cancelado'}
              </Text>
            </View>
            <Text style={styles.customer}>{o.customer}</Text>
            <Text style={styles.date}>{fmtDateTime(o.created_at)}</Text>
            {o.items.map((it, i) => <Text key={i} style={styles.item}>• {it.qty}x {it.name}</Text>)}
            {!!o.notes && <Text style={styles.notes}>📝 {o.notes}</Text>}
            <View style={styles.foot}>
              <Text style={styles.pay}>💳 {o.payment}</Text>
              <Text style={styles.total}>{fmtMoney(o.total)}</Text>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  search: { flexDirection: 'row', alignItems: 'center', gap: 10, margin: 16, marginBottom: 8, paddingHorizontal: 14, backgroundColor: colors.card2, borderRadius: 999 },
  input: { flex: 1, color: colors.text, paddingVertical: 12 },
  filters: { flexDirection: 'row', gap: 8, paddingHorizontal: 16 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  chipOn: { backgroundColor: colors.neon, borderColor: colors.neon },
  chipText: { color: colors.text, fontWeight: '700' },
  empty: { color: colors.muted, textAlign: 'center', marginTop: 60 },
  card: { backgroundColor: colors.card2, borderRadius: radius.md, padding: 16, marginBottom: 12 },
  head: { flexDirection: 'row', justifyContent: 'space-between' },
  number: { color: colors.neon, fontWeight: '800' },
  status: { fontWeight: '800' },
  customer: { color: colors.text, fontSize: 18, fontWeight: '700', marginTop: 2 },
  date: { color: colors.muted, fontSize: 12, marginBottom: 8 },
  item: { color: colors.text, fontSize: 14 },
  notes: { color: colors.yellow, marginTop: 4 },
  foot: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border },
  pay: { color: colors.muted, fontWeight: '600' },
  total: { color: colors.green, fontWeight: '800', fontSize: 18 },
});
