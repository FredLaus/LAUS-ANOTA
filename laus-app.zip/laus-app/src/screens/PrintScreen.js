// Configurações de Impressão (com impressão de teste via sistema do celular).
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Switch, Text, View, Pressable } from 'react-native';
import * as Print from 'expo-print';
import TopBar from '../components/TopBar';
import { Button, Field, Section } from '../components/Ui';
import { colors, radius } from '../theme';
import { useApp } from '../context/AppContext';
import { fmtMoney } from '../utils';

export default function PrintScreen() {
  const { settings, setSetting } = useApp();
  const [header, setHeader] = useState('');
  const [copies, setCopies] = useState('1');

  useEffect(() => {
    setHeader(settings.print_header || '');
    setCopies(settings.print_copies || '1');
  }, [settings.print_header, settings.print_copies]);

  const width = settings.print_width || '80';

  const save = async () => {
    const c = Math.min(5, Math.max(1, parseInt(copies, 10) || 1));
    await setSetting('print_header', header.trim());
    await setSetting('print_copies', c);
    setCopies(String(c));
    Alert.alert('Salvo', 'Configurações de impressão atualizadas.');
  };

  const testPrint = async () => {
    const mm = width === '58' ? 58 : 80;
    const html = `
      <html><body style="width:${mm}mm;font-family:monospace;font-size:13px">
        <h3 style="text-align:center">${header || 'LAUS'}</h3>
        <p style="text-align:center">${settings.rest_name || ''}</p><hr/>
        <p><b>PEDIDO DE TESTE #0000</b></p>
        <p>1x X-Burger Clássico</p><p>Obs: sem cebola</p><hr/>
        <p><b>Total: ${fmtMoney(28.9)}</b> (Pix)</p>
      </body></html>`;
    try {
      await Print.printAsync({ html, width: mm * 2.83 });
    } catch (e) {
      Alert.alert('Não foi possível imprimir', 'Verifique se há uma impressora disponível no aparelho.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <TopBar title="Configurações de Impressão" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        <Section title="Impressão automática">
          <View style={styles.row}>
            <Text style={styles.rowText}>Imprimir ao aceitar pedido</Text>
            <Switch
              value={settings.print_auto === '1'}
              onValueChange={(v) => setSetting('print_auto', v ? '1' : '0')}
              trackColor={{ false: colors.off, true: colors.neon }}
              thumbColor="#fff"
            />
          </View>
        </Section>
        <Section title="Largura do papel">
          <View style={styles.row}>
            {['58', '80'].map((w) => (
              <Pressable key={w} onPress={() => setSetting('print_width', w)} style={[styles.chip, width === w && styles.chipOn]}>
                <Text style={[styles.chipText, width === w && { color: '#000' }]}>{w} mm</Text>
              </Pressable>
            ))}
          </View>
        </Section>
        <Section title="Comprovante">
          <Field label="Cabeçalho" value={header} onChangeText={setHeader} />
          <Field label="Número de vias (1 a 5)" value={copies} onChangeText={setCopies} keyboardType="number-pad" />
          <Button title="Salvar" onPress={save} />
        </Section>
        <Button title="Imprimir página de teste" onPress={testPrint} ghost />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  rowText: { color: colors.text, fontSize: 15, flex: 1 },
  chip: { flex: 1, paddingVertical: 12, borderRadius: radius.sm, backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.border, alignItems: 'center' },
  chipOn: { backgroundColor: colors.neon, borderColor: colors.neon },
  chipText: { color: colors.text, fontWeight: '700' },
});
