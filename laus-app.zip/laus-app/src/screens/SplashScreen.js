// Tela de abertura: logo no centro + barra de carregamento suave por 2,5 s.
import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import Logo from '../components/Logo';
import { colors } from '../theme';
import { APP_NAME, TAGLINE } from '../config';

export const SPLASH_MS = 2500;

export default function SplashScreen({ onDone }) {
  const fade = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(0.85)).current;
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 900, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1, duration: 900, easing: Easing.out(Easing.back(1.4)), useNativeDriver: true }),
    ]).start();
    Animated.timing(progress, {
      toValue: 1, duration: SPLASH_MS, easing: Easing.inOut(Easing.cubic), useNativeDriver: false,
    }).start(({ finished }) => finished && onDone());
  }, [fade, scale, progress, onDone]);

  const width = progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] });

  return (
    <View style={styles.container}>
      <Animated.View style={{ alignItems: 'center', opacity: fade, transform: [{ scale }] }}>
        <Logo size={150} />
        <Text style={styles.name}>{APP_NAME}</Text>
        <Text style={styles.tag}>{TAGLINE}</Text>
      </Animated.View>
      <View style={styles.track}>
        <Animated.View style={[styles.fill, { width }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' },
  name: { color: colors.text, fontSize: 38, fontWeight: '900', letterSpacing: 8, marginTop: 20 },
  tag: { color: colors.neon, fontSize: 14, letterSpacing: 2, marginTop: 6 },
  track: { position: 'absolute', bottom: 90, width: '55%', height: 4, borderRadius: 2, backgroundColor: colors.card2, overflow: 'hidden' },
  fill: { height: '100%', backgroundColor: colors.neon, borderRadius: 2 },
});
