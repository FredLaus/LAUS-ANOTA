// Esteira de Pedidos: 3 abas deslizantes (Em Análise / Em Produção / Retirada-Entrega).
import React, { useEffect, useRef, useState } from 'react';
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import TopBar from '../components/TopBar';
import OrderCard from '../components/OrderCard';
import { colors, radius } from '../theme';
import { useApp } from '../context/AppContext';

const COLUMNS = [
  { key: 'analise', label: 'Em Análise', empty: 'Nenhum pedido aguardando análise.' },
  { key: 'producao', label: 'Em Produção', empty: 'Nenhum pedido em produção.' },
  { key: 'entrega', label: 'Aguardando Retirada / Saiu para Entrega', empty: 'Nenhum pedido aguardando retirada ou em entrega.' },
];

export default function OrdersScreen() {
  const { orders, moveOrder, addDemoOrder } = useApp();
  const [tab, setTab] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [width, setWidth] = useState(0);
  const pager = useRef(null);

  // Relógio de 1 s para atualizar todos os cronômetros
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const goTo = (i) => {
    setTab(i);
    pager.current?.scrollTo({ x: i * width, animated: true });
  };

  const addTest = (
    <Pressable onPress={addDemoOrder} hitSlop={8} accessibilityLabel="Simular novo pedido">
      <Text style={styles.testBtn}>＋ Teste</Text>
    </Pressable>
  );

  return (
    <View style={styles.container}>
      <TopBar title="Pedidos" right={addTest} />

      <View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          {COLUMNS.map((c, i) => {
            const count = orders.filter((o) => o.status === c.key).length;
            const active = tab === i;
            return (
              <Pressable key={c.key} onPress={() => goTo(i)} style={[styles.chip, active && styles.chipActive]}>
                <Text style={[styles.chipText, active && { color: '#000' }]}>{c.label}</Text>
                <View style={[styles.badge, active && { backgroundColor: '#000' }]}>
                  <Text style={[styles.badgeText, active && { color: colors.neon }]}>{count}</Text>
                </View>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      <View style={{ flex: 1 }} onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
        {width > 0 && (
          <ScrollView
            ref={pager}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onMomentumScrollEnd={(e) => setTab(Math.round(e.nativeEvent.contentOffset.x / width))}
          >
            {COLUMNS.map((c) => {
              const data = orders.filter((o) => o.status === c.key);
              return (
                <View key={c.key} style={{ width }}>
                  <FlatList
                    data={data}
                    keyExtractor={(o) => String(o.id)}
                    contentContainerStyle={{ padding: 16 }}
                    renderItem={({ item }) => <OrderCard order={item} now={now} onMove={moveOrder} />}
                    ListEmptyComponent={<Text style={styles.empty}>{c.empty}</Text>}
                  />
                </View>
              );
            })}
          </ScrollView>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  testBtn: { color: colors.neon, fontWeight: '700' },
  chips: { paddingHorizontal: 16, paddingVertical: 12, gap: 8 },
  chip: {
    flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 14, paddingVertical: 9,
    borderRadius: 999, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
  },
  chipActive: { backgroundColor: colors.neon, borderColor: colors.neon },
  chipText: { color: colors.text, fontWeight: '700' },
  badge: { minWidth: 22, height: 22, borderRadius: 11, backgroundColor: colors.card2, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 },
  badgeText: { color: colors.text, fontWeight: '800', fontSize: 12 },
  empty: { color: colors.muted, textAlign: 'center', marginTop: 60 },
});
