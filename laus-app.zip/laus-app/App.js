import 'react-native-gesture-handler';
import React, { useCallback, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppProvider, useApp } from './src/context/AppContext';
import Navigation, { navRef } from './src/navigation';
import SplashScreen from './src/screens/SplashScreen';
import WhatsAppModal from './src/components/WhatsAppModal';

function Root() {
  const { ready } = useApp();
  const [splashDone, setSplashDone] = useState(false);
  const onDone = useCallback(() => setSplashDone(true), []);

  // Mantém a splash por 2,5 s e também até o banco estar pronto
  if (!(splashDone && ready)) return <SplashScreen onDone={onDone} />;

  return (
    <>
      <Navigation />
      <WhatsAppModal onOpenSettings={() => navRef.current?.navigate('Configuracoes')} />
    </>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: '#000' }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <AppProvider>
          <Root />
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
